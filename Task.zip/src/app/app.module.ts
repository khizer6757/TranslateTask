import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { NgxFileDropModule } from 'ngx-file-drop';
import { PdfViewerModule } from 'ng2-pdf-viewer';

import { LeftComponentComponent } from './components/left-component/left-component.component';
import { MiddleComponentComponent } from './components/middle-component/middle-component.component';
import { RightComponentComponent } from './components/right-component/right-component.component';

@NgModule({
  declarations: [
    AppComponent,
    LeftComponentComponent,
    MiddleComponentComponent,
    RightComponentComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    NgxFileDropModule,
    PdfViewerModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
