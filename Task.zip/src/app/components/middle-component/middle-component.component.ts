import { Component, Input, OnInit } from '@angular/core';
import { ChangeIndexService } from 'src/app/services/change-index.service';

@Component({
  selector: 'app-middle-component',
  templateUrl: './middle-component.component.html',
  styleUrls: ['./middle-component.component.scss']
})
export class MiddleComponentComponent implements OnInit {

  @Input() item; 
  @Input() namesList; 
  index: number;
 
  constructor(
    private indexService:ChangeIndexService
  ) { 
  }

 
  ngOnInit(): void {
    console.log(this.item);
    this.indexService.currentCD.subscribe((index)=>{
      console.log(index);
      
      this.index=Number(index);
    })
  } 
}
