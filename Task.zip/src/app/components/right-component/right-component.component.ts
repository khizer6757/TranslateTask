import { Component, Input, OnInit, Output } from '@angular/core';
import { EventEmitter } from '@angular/core';
import { ChangeIndexService } from 'src/app/services/change-index.service';

@Component({
  selector: 'app-right-component',
  templateUrl: './right-component.component.html',
  styleUrls: ['./right-component.component.scss']
})
export class RightComponentComponent implements OnInit {
  @Input() names="";


  constructor(
    private selectPdf:ChangeIndexService
  ) { }

  ngOnInit(): void {
  }

  sendPDFIndex(value) {
    this.selectPdf.changeCD(value);
  }

}
