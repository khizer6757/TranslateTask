import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class ChangeIndexService {

  private changeIndex = new BehaviorSubject<string>('0');
  currentCD = this.changeIndex.asObservable();

  constructor() { }

  changeCD(m: string) {
    this.changeIndex.next(m);
  }
}
