import { TestBed } from '@angular/core/testing';

import { ChangeIndexService } from './change-index.service';

describe('ChangeIndexService', () => {
  let service: ChangeIndexService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(ChangeIndexService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
